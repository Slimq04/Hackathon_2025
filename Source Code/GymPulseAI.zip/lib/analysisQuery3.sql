WITH base_analysis AS (
    SELECT
        -- Basic Review Info
        {{ reviewInput.value }} as review,
        TRIM(REGEXP_REPLACE({{ reviewInput.value }}, '[\n\r]', ' ')) AS cleaned_review
),

sentiment_analysis AS (
    SELECT 
        *,
        -- Enhanced Sentiment Analysis
        snowflake.cortex.sentiment(cleaned_review) AS sentiment_score,
        ROUND(snowflake.cortex.sentiment(cleaned_review), 2) AS sentiment_score_rounded
    FROM base_analysis
),

urgency_analysis AS (
    SELECT 
        *,
        -- Enhanced Urgency Classification
        snowflake.cortex.complete(
            'mistral-large2',
            CONCAT(
                'Analyze the urgency of this review and provide a structured response in this exact format: ',
                'URGENCY LEVEL: [Critical/Moderate/Low]|REASON: [brief explanation]|ACTION: [recommended action] ',
                '\n\nCritical Urgency criteria: ',
                '- Safety concerns, injuries, or health hazards ',
                '- Equipment defects or failures causing immediate risk ',
                '- Urgent refund demands or billing fraud claims ',
                '- Legal threats or discrimination claims ',
                '- Keywords: "urgent", "immediately", "emergency", "danger", "injured", "lawsuit", "fraudulent charge" ',
                '\n\nModerate Urgency criteria: ',
                '- Service failures requiring timely resolution ',
                '- Billing disputes or unexpected charges ',
                '- Staff misconduct or poor customer service ',
                '- Membership or heartrate monitor price feels expensive',
                '- Keywords: "disappointed", "unacceptable", "need resolution", "charged incorrectly" ',
                '\n\nLow Urgency criteria: ',
                '- General feedback or suggestions ',
                '- Praise or positive experiences ',
                '- Minor inconveniences ',
                '\n\nReview: "', cleaned_review, '"'
            )
        ) AS urgency_raw
    FROM sentiment_analysis
),

tag_analysis AS (
    SELECT 
        *,
        -- Enhanced Tagging
        snowflake.cortex.complete(
            'mistral-large2',
            CONCAT(
                'Analyze EVERY aspect of this review and assign ALL applicable tags.\n',
                'IMPORTANT: Check for BOTH positive AND negative mentions in each category.\n\n',
                'Categorize this review using EXACTLY this format:\n',
                'Output format (exactly 7 lines):\n',
                'STUDIO EXPERIENCE: [tags or None]\n',
                'CLASS EXPERIENCE: [tags or None]\n',
                'COACH: [tags or None]\n',
                'STUDIO STAFF: [tags or None]\n',
                'PRICING: [tags or None]\n',
                'EQUIPMENT: [tags or None]\n',
                'INJURY: [tags or None]\n\n',
                
                'IMPORTANT RULES:\n',
                '1. Use "None" ONLY when NO tags from that category apply\n',
                '2. NEVER add "None" if you already listed tags for that category\n',
                '3. List ONLY the applicable tags, separated by commas\n',
                '4. Do NOT mix actual tags with "None" in the same line\n\n',
                
                'Available tags per category:\n',
                '- STUDIO EXPERIENCE: Motivating Atmosphere, Clean Studio, Dirty Studio, Overcrowded\n',
                '- CLASS EXPERIENCE: Great Workout, Effective Results, Overwhelming Classes, Too Intense, No Results\n',
                '- COACH: Excellent Coaching, Poor Instruction\n',
                '- STUDIO STAFF: Friendly Staff, Professional Trainers, Responsive Support, Rude Staff, Unprofessional Behavior, Poor Communication, Pushy Sales\n',
                '- PRICING: Worth the Cost, Good Value, Fair Pricing, Too Expensive, Hidden Fees, Billing Issues, Not Worth It\n',
                '- EQUIPMENT: Quality Equipment, Well-Maintained, Good Technology, Broken Equipment, Inaccurate Monitors, Technical Issues\n',
                '- INJURY: Injury Concerns\n\n',
                
                'Review: "', cleaned_review, '"'
            )
        ) AS categorized_tags_raw
    FROM urgency_analysis
)

-- Main query with all formatted outputs
SELECT 
    -- 1. SENTIMENT SECTION DATA
    review,
    cleaned_review,
    sentiment_score,
    sentiment_score_rounded,
    CASE
        WHEN sentiment_score_rounded <= -0.8 THEN 'Extremely Negative'
        WHEN sentiment_score_rounded <= -0.6 THEN 'Very Negative'
        WHEN sentiment_score_rounded <= -0.3 THEN 'Negative'
        WHEN sentiment_score_rounded <= -0.1 THEN 'Slightly Negative'
        WHEN sentiment_score_rounded <= 0.1 THEN 'Neutral'
        WHEN sentiment_score_rounded <= 0.3 THEN 'Slightly Positive'
        WHEN sentiment_score_rounded <= 0.6 THEN 'Positive'
        WHEN sentiment_score_rounded <= 0.8 THEN 'Very Positive'
        ELSE 'Extremely Positive'
    END AS sentiment_tier,
    
    CASE
        WHEN ABS(sentiment_score) >= 0.8 THEN 'High Confidence'
        WHEN ABS(sentiment_score) >= 0.5 THEN 'Medium Confidence'
        ELSE 'Low Confidence'
    END AS sentiment_confidence,
    
    -- 2. URGENCY SECTION DATA
    TRIM(SPLIT_PART(urgency_raw, '|', 1)) AS urgency_level,
    TRIM(SPLIT_PART(urgency_raw, '|', 2)) AS urgency_reason,
    TRIM(SPLIT_PART(urgency_raw, '|', 3)) AS recommended_action,
    
    -- 3. TAGS AS INDIVIDUAL FIELDS (for easy Retool table display)
    COALESCE(
        TRIM(REGEXP_REPLACE(
            REGEXP_SUBSTR(categorized_tags_raw, 'STUDIO EXPERIENCE: ([^\\n]+)', 1, 1, 'e'),
            ', None|None, ', ''
        )), 'None'
    ) AS studio_experience_tags,
    
    COALESCE(
        TRIM(REGEXP_REPLACE(
            REGEXP_SUBSTR(categorized_tags_raw, 'CLASS EXPERIENCE: ([^\\n]+)', 1, 1, 'e'),
            ', None|None, ', ''
        )), 'None'
    ) AS class_experience_tags,
    
    COALESCE(
        TRIM(REGEXP_REPLACE(
            REGEXP_SUBSTR(categorized_tags_raw, 'COACH: ([^\\n]+)', 1, 1, 'e'),
            ', None|None, ', ''
        )), 'None'
    ) AS coach_tags,
    
    COALESCE(
        TRIM(REGEXP_REPLACE(
            REGEXP_SUBSTR(categorized_tags_raw, 'STUDIO STAFF: ([^\\n]+)', 1, 1, 'e'),
            ', None|None, ', ''
        )), 'None'
    ) AS studio_staff_tags,
    
    COALESCE(
        TRIM(REGEXP_REPLACE(
            REGEXP_SUBSTR(categorized_tags_raw, 'PRICING: ([^\\n]+)', 1, 1, 'e'),
            ', None|None, ', ''
        )), 'None'
    ) AS pricing_tags,
    
    COALESCE(
        TRIM(REGEXP_REPLACE(
            REGEXP_SUBSTR(categorized_tags_raw, 'EQUIPMENT: ([^\\n]+)', 1, 1, 'e'),
            ', None|None, ', ''
        )), 'None'
    ) AS equipment_tags,
    
    COALESCE(
        TRIM(REGEXP_REPLACE(
            REGEXP_SUBSTR(categorized_tags_raw, 'INJURY: ([^\\n]+)', 1, 1, 'e'),
            ', None|None, ', ''
        )), 'None'
    ) AS injury_tags
    
FROM tag_analysis;