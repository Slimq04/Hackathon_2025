SELECT review,
       studio_id,
       sentiment_tier,
       urgency_level,
       studio_exp,
       class_exp,
       coach_exp AS coach,
       staff,
       price,
       equipment,
       injury
FROM GYMPULSE_AI.ANALYZED_REVIEW;