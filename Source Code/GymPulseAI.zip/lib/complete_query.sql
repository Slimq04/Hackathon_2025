SELECT '{{ reviewInput.value }}' as review,
       REGEXP_REPLACE(review, '[\n\r]', '') AS cleaned_review,
       snowflake.cortex.sentiment(cleaned_review)  AS sentiment_score,
-- 1. Polarization
       CASE
            WHEN ROUND(sentiment_score, 2) <= -0.7 THEN 'Strongly Negative'
            WHEN ROUND(sentiment_score, 2) <= -0.3 THEN 'Negative'
            WHEN ROUND(sentiment_score, 2) <= -0.01 THEN 'Slightly Negetive'
            WHEN ROUND(sentiment_score, 2) <= 0.3 THEN 'Slightly Positive'
            WHEN ROUND(sentiment_score, 2) <= 0.7 THEN 'Moderately Positive'
            WHEN ROUND(sentiment_score, 2) <= 1 THEN 'Highly Positive'
            ELSE 'Neutral'
       END AS sentiment_tier,
      snowflake.cortex.complete(
               'mistral-7b',
               CONCAT(
                       'Classify the urgency of the following review into one of three categories: Critical Urgency, Moderate Urgency, or Low Urgency. ',
                       'Critical Urgency includes reviews with immediate issues like safety concerns, defects, or urgent demands, indicated by words/phrases like: ',
                       '"urgent", "immediately", "emergency", "danger", "hazard", "defective", "broken", "faulty", "unsafe", "serious", "severe", "crisis", ',
                       '"refund now", "fix now", "safety concern", "health hazard", "caused injury", "life-threatening", "needs immediate attention". ',
                       'Moderate Urgency includes significant complaints needing timely attention, with words like "disappointing", "issue", "problem", "fix", "poor". ',
                       'Low Urgency includes general feedback or praise, with words like "good", "could improve", "great". ',
                       'Review: "', cleaned_review, '". Return only the urgency category.'
               )
       )                                                   AS urgency_tier, 
      SPLIT_PART(urgency_tier, '.', 1) AS urgency_category,
      SPLIT_PART(urgency_tier, '.', 2) as urgency_reason,
      SNOWFLAKE.CORTEX.COMPLETE(
        'mistral-7b',
        CONCAT(
            'Tag the following review with one or more of these tags based on its content: ',
            -- Positive tags
            'Good Workout Experience, Good Performance Tracking, Benefits for Physical and Mental, Good Studio Environment, Good Staff and Community, ',
            -- Negative tags
            'Expensive Membership, Expensive Heartrate Monitor, Unexpected Charges, Limited Class Availability, Inconvenient Class Times, ',
            'Overwhelming Classes, Lack of Variety, Lack of Results, Poor Coaching, Poor Communication, Unfriendly Staff, Insufficient Instruction, ',
            'Excessive Noise, Unclean Studio, Overcrowded Studio, Poor Equipment Quality, Weak Community, Inaccurate Equipment, Injury Concerns, ',
            'Personal Reasons, Relocation, Studio Closure, Changed Membership, Sales Pressure.',
            'Use "Other" for feedback if none of specific tags above is matched.' ,
            'For Active Members, focus on positive keywords like variety, challenges, efficiency, and negative keywords like class availability, crowded, heartrate monitor accuracy. ',
            'For Terminations, focus on positive reflective keywords like enjoyed, liked, and negative keywords like value, relocation, personal reasons. ',
            'For Intro Classes, focus on positive keywords like pre-workout, welcoming, clear instruction, and negative keywords like sales pressure, pre-class instruction, first impressions. ',
            'Return the tags as a comma-separated list (e.g., "Tag1, Tag2"). ',
            'Review: "', REGEXP_REPLACE(cleaned_review, '[\n\r]', ' '), '". Return only the urgency category.'
        )
    ) AS review_tags