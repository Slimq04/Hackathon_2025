SELECT
    -- Basic Review Info
    {{ reviewInput.value }}  as review,
    REGEXP_REPLACE(review, '[\n\r]', ' ') AS cleaned_review,

    -- Enhanced Sentiment Analysis
    snowflake.cortex.sentiment(cleaned_review) AS sentiment_score,
    ROUND(sentiment_score, 2) AS sentiment_score_rounded,

    -- Sentiment Categorization with Better Granularity
    CASE
        WHEN ROUND(sentiment_score, 2) <= -0.8 THEN 'Extremely Negative'
        WHEN ROUND(sentiment_score, 2) <= -0.6 THEN 'Very Negative'
        WHEN ROUND(sentiment_score, 2) <= -0.3 THEN 'Negative'
        WHEN ROUND(sentiment_score, 2) <= -0.1 THEN 'Slightly Negative'
        WHEN ROUND(sentiment_score, 2) <= 0.1 THEN 'Neutral'
        WHEN ROUND(sentiment_score, 2) <= 0.3 THEN 'Slightly Positive'
        WHEN ROUND(sentiment_score, 2) <= 0.6 THEN 'Positive'
        WHEN ROUND(sentiment_score, 2) <= 0.8 THEN 'Very Positive'
        ELSE 'Extremely Positive'
    END AS sentiment_tier,

    -- Sentiment Confidence Level
    CASE
        WHEN ABS(sentiment_score) >= 0.8 THEN 'High Confidence'
        WHEN ABS(sentiment_score) >= 0.5 THEN 'Medium Confidence'
        ELSE 'Low Confidence'
    END AS sentiment_confidence,

    -- Enhanced Urgency Classification
    snowflake.cortex.complete(
        'mistral-large2',
        CONCAT(
            'Analyze the urgency of this review and provide a structured response in this exact format: ',
            'URGENCY LEVEL: [Critical/Moderate/Low]|REASON: [brief explanation]|ACTION: [recommended action] ',
            '\n\nCritical Urgency criteria: ',
            '- Safety concerns, injuries, or health hazards ',
            '- Equipment defects or failures causing immediate risk ',
            '- Urgent refund demands or billing fraud claims ',
            '- Legal threats or discrimination claims ',
            '- Keywords: "urgent", "immediately", "emergency", "danger", "injured", "lawsuit", "fraudulent charge" ',
            '\n\nModerate Urgency criteria: ',
            '- Service failures requiring timely resolution ',
            '- Billing disputes or unexpected charges ',
            '- Staff misconduct or poor customer service ',
            '- Membership or heartrate monitor price feels expensive',
            '- Keywords: "disappointed", "unacceptable", "need resolution", "charged incorrectly" ',
            '\n\nLow Urgency criteria: ',
            '- General feedback or suggestions ',
            '- Praise or positive experiences ',
            '- Minor inconveniences ',
            '\n\nReview: "', cleaned_review, '"'
        )
    ) AS urgency_analysis,

    -- Parse urgency components
    SPLIT_PART(urgency_analysis, '|', 1) AS urgency_level,
    SPLIT_PART(urgency_analysis, '|', 2) AS urgency_reason,
    SPLIT_PART(urgency_analysis, '|', 3) AS recommended_action,

        -- Enhanced Tagging with Categories
    snowflake.cortex.complete(
        'mistral-large2',
    CONCAT(
        'Analyze EVERY aspect of this review and assign ALL applicable tags.\n',
        'IMPORTANT: Check for BOTH positive AND negative mentions in each category.\n\n',

      'Categorize this review using EXACTLY this format:\n',
       'Output format (exactly 7 lines):\n',
       'STUDIO EXPERIENCE: [tags or None]\n',
       'CLASS EXPERIENCE: [tags or None]\n',
       'COACH: [tags or None]\n',
       'STUDIO STAFF: [tags or None]\n',
       'PRICING: [tags or None]\n',
       'EQUIPMENT FACILITY: [tags or None]\n',
       'INJURY: [tags or None]\n\n',
        
        'IMPORTANT RULES:\n',
        '1. Use "None" ONLY when NO tags from that category apply\n',
        '2. NEVER add "None" if you already listed tags for that category\n',
        '3. List ONLY the applicable tags, separated by commas\n',
        '4. Do NOT mix actual tags with "None" in the same line\n\n',
        
        'Example of CORRECT output:\n',
        'STUDIO EXPERIENCE: Clean Studio, Motivating Atmosphere\n',
        'CLASS EXPERIENCE: Great Workout\n',
        'COACH: None\n',
        'STUDIO STAFF: Friendly Staff\n',
        'PRICING: Too Expensive\n',
        'EQUIPMENT: None\n',
        'INJURY: None\n\n',
        
        'Example of WRONG output (do NOT do this):\n',
        'STUDIO EXPERIENCE: Clean Studio, None ← WRONG! Dont add None if tags exist\n',
        'PRICING: None, None ← WRONG! Only one None needed\n\n',
      
        'Instructions for each category:\n',
        '- STUDIO EXPERIENCE: Look for mentions of atmosphere, cleanliness, crowding\n',
        '  Tags: Motivating Atmosphere, Clean Studio, Dirty Studio, Overcrowded\n\n',

        '- CLASS EXPERIENCE: Look for ANY mention of classes, workouts, results, availability, timing issue\n',
        '  Positive tags : Great Workout, Effective Results\n',
        '  Negative tags: Overwhelming Classes, Too Intense, No Results\n',
        '  NOTE: "classes are good" = Great Workout\n\n',

        '- COACH: Look for mentions of coaching, instruction\n',
        '  Tags: Excellent Coaching, Poor Instruction\n\n',

        '- STUDIO STAFF: Look for mentions of staff behavior, communication, policies, employee mentions\n',
        '  Tags: Friendly Staff, Professional Trainers, Responsive Support, Rude Staff, Unprofessional Behavior, Poor Communication, Pushy Sales\n',
        '  NOTE: Poor policy communication = Poor Communication\n\n',

        '- PRICING: Look for mentions of cost, fees, charges, value\n',
        '  Tags: Worth the Cost, Good Value, Fair Pricing, Too Expensive, Hidden Fees, Billing Issues, Not Worth It\n\n',

        '- EQUIPMENT: Look for mentions of equipment, monitors, technology\n',
        '  Tags: Quality Equipment, Well-Maintained, Good Technology, Broken Equipment, Inaccurate Monitors, Technical Issues\n\n',

        '- INJURY: Look for injury mentions\n',
        '  Tags: Injury Concerns\n\n',

        'Review: "', cleaned_review, '"\n\n',
        'Use EXACTLY the format shown in the example. Remember: Tag ALL aspects mentioned, both positive and negative! Return should be EITHER tags OR None!'
    )
      ) AS categorized_tags,
      
  CONCAT_WS('\n',
        COALESCE(REGEXP_SUBSTR(categorized_tags, 'STUDIO EXPERIENCE:[^\\n]+'), 'STUDIO EXPERIENCE: None'),
        COALESCE(REGEXP_SUBSTR(categorized_tags, 'CLASS EXPERIENCE:[^\\n]+'), 'CLASS EXPERIENCE: None'),
        COALESCE(REGEXP_SUBSTR(categorized_tags, 'COACH:[^\\n]+'), 'COACH: None'),
        COALESCE(REGEXP_SUBSTR(categorized_tags, 'STUDIO STAFF:[^\\n]+'), 'STUDIO_STAFF: None'),
        COALESCE(REGEXP_SUBSTR(categorized_tags, 'PRICING:[^\\n]+'), 'PRICING: None'),
        COALESCE(REGEXP_SUBSTR(categorized_tags, 'EQUIPMENT:[^\\n]+'), 'EQUIPMENT: None'),
        COALESCE(REGEXP_SUBSTR(categorized_tags, 'INJURY:[^\\n]+'), 'INJURY: None')
    ) AS cleaned_tags;